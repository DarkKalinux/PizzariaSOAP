package service;

import dao.ClienteDAO;
import dao.PedidoDAO;
import model.Cliente;
import model.Pedido;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.util.List;

@Stateless
public class PizzariaService {
    @Inject
    private ClienteDAO clienteDAO;
    @Inject
    private PedidoDAO pedidoDAO;

    public void criarCliente(Cliente cliente) {
        clienteDAO.salvar(cliente);
    }

    public void criarPedido(Pedido pedido) {
        pedidoDAO.salvar(pedido);
    }

    public Pedido buscarPedido(Long id) {
        return pedidoDAO.buscar(id);
    }

    public List<Pedido> listarPedidos() {
        return pedidoDAO.listarTodos();
    }
}
