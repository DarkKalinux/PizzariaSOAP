package dao;

import model.Pedido;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

public class PedidoDAO {
    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void salvar(Pedido pedido) {
        em.persist(pedido);
    }

    public Pedido buscar(Long id) {
        return em.find(Pedido.class, id);
    }

    public List<Pedido> listarTodos() {
        return em.createQuery("SELECT p FROM Pedido p", Pedido.class).getResultList();
    }
}
