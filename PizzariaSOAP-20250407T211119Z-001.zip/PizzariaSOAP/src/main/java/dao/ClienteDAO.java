package dao;

import model.Cliente;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@Stateless
public class ClienteDAO {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void salvar(Cliente cliente) {
        em.persist(cliente);
    }

    public Cliente buscar(Long id) {
        return em.find(Cliente.class, id);
    }

    public List<Cliente> listarTodos() {
        return em.createQuery("SELECT c FROM Cliente c", Cliente.class).getResultList();
    }
}
