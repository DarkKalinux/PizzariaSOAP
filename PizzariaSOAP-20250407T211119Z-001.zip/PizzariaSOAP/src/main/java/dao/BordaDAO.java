package dao;

import model.Borda;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@Stateless
public class BordaDAO {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void salvar(Borda borda) {
        em.persist(borda);
    }

    public Borda buscar(Long id) {
        return em.find(Borda.class, id);
    }

    public List<Borda> listarTodos() {
        return em.createQuery("SELECT b FROM Borda b", Borda.class).getResultList();
    }
}