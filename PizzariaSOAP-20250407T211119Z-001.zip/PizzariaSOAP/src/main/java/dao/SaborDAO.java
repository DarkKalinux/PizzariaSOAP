package dao;

import model.Sabor;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@Stateless
public class SaborDAO {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void salvar(Sabor sabor) {
        em.persist(sabor);
    }

    public Sabor buscar(Long id) {
        return em.find(Sabor.class, id);
    }

    public List<Sabor> listarTodos() {
        return em.createQuery("SELECT s FROM Sabor s", Sabor.class).getResultList();
    }
}
