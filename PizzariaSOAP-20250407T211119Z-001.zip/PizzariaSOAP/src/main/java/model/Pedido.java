package model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Cliente cliente;

    @ManyToMany
    private List<Sabor> sabores;

    @ManyToOne
    private Borda borda;

    @Enumerated(EnumType.STRING)
    private StatusPedido status;

    private double valorTotal;

    // Getters e Setters
}
