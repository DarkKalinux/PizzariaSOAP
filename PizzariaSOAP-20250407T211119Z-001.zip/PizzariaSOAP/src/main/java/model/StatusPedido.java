package model;

public enum StatusPedido {
    RECEBIDO,
    EM_PREPARO,
    PRONTO_PARA_RETIRADA,
    SAIU_PARA_ENTREGA,
    ENTREGUE;
}
