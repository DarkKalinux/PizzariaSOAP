package ws;

import model.Cliente;
import model.Pedido;
import service.PizzariaService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.inject.Inject;
import java.util.List;

@WebService
public class PizzariaWS {
    @Inject
    private PizzariaService service;

    @WebMethod
    public void cadastrarCliente(Cliente cliente) {
        service.criarCliente(cliente);
    }

    @WebMethod
    public void fazerPedido(Pedido pedido) {
        service.criarPedido(pedido);
    }

    @WebMethod
    public Pedido buscarPedido(Long id) {
        return service.buscarPedido(id);
    }

    @WebMethod
    public List<Pedido> listarPedidos() {
        return service.listarPedidos();
    }
}
