package com.example.pizzariasoap;

import model.Cliente;
import model.Pedido;
import service.PizzariaService;
import jakarta.inject.Inject;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import java.util.List;

@WebService(serviceName = "PizzariaService")
public class PizzariaResource {

    @Inject
    private PizzariaService service;

    @WebMethod
    public void cadastrarCliente(Cliente cliente) {
        service.criarCliente(cliente);
    }

    @WebMethod
    public void fazerPedido(Pedido pedido) {
        service.criarPedido(pedido);
    }

    @WebMethod
    public Pedido buscarPedido(Long id) {
        return service.buscarPedido(id);
    }

    @WebMethod
    public List<Pedido> listarPedidos() {
        return service.listarPedidos();
    }
}